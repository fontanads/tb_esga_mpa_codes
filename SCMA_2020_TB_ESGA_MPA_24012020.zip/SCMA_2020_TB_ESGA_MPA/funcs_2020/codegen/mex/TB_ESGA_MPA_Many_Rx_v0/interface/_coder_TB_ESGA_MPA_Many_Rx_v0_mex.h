/*
 * _coder_TB_ESGA_MPA_Many_Rx_v0_mex.h
 *
 * Code generation for function '_coder_TB_ESGA_MPA_Many_Rx_v0_mex'
 *
 */

#ifndef _CODER_TB_ESGA_MPA_MANY_RX_V0_MEX_H
#define _CODER_TB_ESGA_MPA_MANY_RX_V0_MEX_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "TB_ESGA_MPA_Many_Rx_v0_types.h"

/* Function Declarations */
extern void mexFunction(int32_T nlhs, mxArray *plhs[], int32_T nrhs, const
  mxArray *prhs[]);
extern emlrtCTX mexFunctionCreateRootTLS(void);

#endif

/* End of code generation (_coder_TB_ESGA_MPA_Many_Rx_v0_mex.h) */
