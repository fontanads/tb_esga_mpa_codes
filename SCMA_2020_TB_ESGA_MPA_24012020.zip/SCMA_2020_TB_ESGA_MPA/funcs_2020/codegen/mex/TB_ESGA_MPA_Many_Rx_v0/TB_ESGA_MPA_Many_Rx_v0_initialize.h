/*
 * TB_ESGA_MPA_Many_Rx_v0_initialize.h
 *
 * Code generation for function 'TB_ESGA_MPA_Many_Rx_v0_initialize'
 *
 */

#ifndef TB_ESGA_MPA_MANY_RX_V0_INITIALIZE_H
#define TB_ESGA_MPA_MANY_RX_V0_INITIALIZE_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "TB_ESGA_MPA_Many_Rx_v0_types.h"

/* Function Declarations */
extern void TB_ESGA_MPA_Many_Rx_v0_initialize(void);

#endif

/* End of code generation (TB_ESGA_MPA_Many_Rx_v0_initialize.h) */
