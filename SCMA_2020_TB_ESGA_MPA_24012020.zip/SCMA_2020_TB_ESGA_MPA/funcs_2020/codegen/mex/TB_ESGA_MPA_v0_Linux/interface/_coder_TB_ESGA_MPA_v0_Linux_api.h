/*
 * _coder_TB_ESGA_MPA_v0_Linux_api.h
 *
 * Code generation for function '_coder_TB_ESGA_MPA_v0_Linux_api'
 *
 */

#ifndef _CODER_TB_ESGA_MPA_V0_LINUX_API_H
#define _CODER_TB_ESGA_MPA_V0_LINUX_API_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "TB_ESGA_MPA_v0_Linux_types.h"

/* Function Declarations */
extern void TB_ESGA_MPA_v0_Linux_api(const mxArray * const prhs[12], int32_T
  nlhs, const mxArray *plhs[2]);

#endif

/* End of code generation (_coder_TB_ESGA_MPA_v0_Linux_api.h) */
