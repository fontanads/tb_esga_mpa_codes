/*
 * _coder_uplink_SCMA_info.h
 *
 * Code generation for function '_coder_uplink_SCMA_info'
 *
 */

#ifndef _CODER_UPLINK_SCMA_INFO_H
#define _CODER_UPLINK_SCMA_INFO_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "uplink_SCMA_types.h"

/* Function Declarations */
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif

/* End of code generation (_coder_uplink_SCMA_info.h) */
