/*
 * uplink_SCMA_data.h
 *
 * Code generation for function 'uplink_SCMA_data'
 *
 */

#ifndef UPLINK_SCMA_DATA_H
#define UPLINK_SCMA_DATA_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "uplink_SCMA_types.h"

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern const volatile char_T *emlrtBreakCheckR2012bFlagVar;
extern emlrtContext emlrtContextGlobal;

#endif

/* End of code generation (uplink_SCMA_data.h) */
