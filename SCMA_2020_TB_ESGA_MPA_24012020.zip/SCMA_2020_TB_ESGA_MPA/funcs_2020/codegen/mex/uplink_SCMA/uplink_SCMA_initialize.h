/*
 * uplink_SCMA_initialize.h
 *
 * Code generation for function 'uplink_SCMA_initialize'
 *
 */

#ifndef UPLINK_SCMA_INITIALIZE_H
#define UPLINK_SCMA_INITIALIZE_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "uplink_SCMA_types.h"

/* Function Declarations */
extern void uplink_SCMA_initialize(void);

#endif

/* End of code generation (uplink_SCMA_initialize.h) */
