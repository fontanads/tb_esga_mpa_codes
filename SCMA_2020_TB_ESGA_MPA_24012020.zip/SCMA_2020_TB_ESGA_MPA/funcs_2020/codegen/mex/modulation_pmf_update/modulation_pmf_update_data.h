/*
 * modulation_pmf_update_data.h
 *
 * Code generation for function 'modulation_pmf_update_data'
 *
 */

#ifndef MODULATION_PMF_UPDATE_DATA_H
#define MODULATION_PMF_UPDATE_DATA_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "modulation_pmf_update_types.h"

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern const volatile char_T *emlrtBreakCheckR2012bFlagVar;
extern emlrtContext emlrtContextGlobal;
extern emlrtRSInfo g_emlrtRSI;
extern emlrtRSInfo h_emlrtRSI;
extern emlrtRSInfo n_emlrtRSI;
extern emlrtRSInfo o_emlrtRSI;

#endif

/* End of code generation (modulation_pmf_update_data.h) */
