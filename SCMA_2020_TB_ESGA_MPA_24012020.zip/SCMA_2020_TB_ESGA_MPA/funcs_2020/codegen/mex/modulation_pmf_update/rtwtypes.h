/*
 * rtwtypes.h
 *
 * Code generation for function 'modulation_pmf_update'
 *
 */

#ifndef RTWTYPES_H
#define RTWTYPES_H
#include "tmwtypes.h"
/* 
 * TRUE/FALSE definitions
 */
#ifndef TRUE
#define TRUE (1U)
#endif 
#ifndef FALSE
#define FALSE (0U)
#endif 
#endif
/* End of code generation (rtwtypes.h) */
