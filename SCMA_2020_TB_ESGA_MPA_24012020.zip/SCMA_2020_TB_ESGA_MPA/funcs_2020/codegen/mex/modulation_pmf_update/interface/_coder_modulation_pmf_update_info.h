/*
 * _coder_modulation_pmf_update_info.h
 *
 * Code generation for function '_coder_modulation_pmf_update_info'
 *
 */

#ifndef _CODER_MODULATION_PMF_UPDATE_INFO_H
#define _CODER_MODULATION_PMF_UPDATE_INFO_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "modulation_pmf_update_types.h"

/* Function Declarations */
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif

/* End of code generation (_coder_modulation_pmf_update_info.h) */
