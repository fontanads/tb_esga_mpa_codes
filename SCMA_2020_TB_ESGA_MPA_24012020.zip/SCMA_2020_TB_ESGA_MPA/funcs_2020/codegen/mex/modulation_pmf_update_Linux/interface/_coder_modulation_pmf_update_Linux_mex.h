/*
 * _coder_modulation_pmf_update_Linux_mex.h
 *
 * Code generation for function '_coder_modulation_pmf_update_Linux_mex'
 *
 */

#ifndef _CODER_MODULATION_PMF_UPDATE_LINUX_MEX_H
#define _CODER_MODULATION_PMF_UPDATE_LINUX_MEX_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "modulation_pmf_update_Linux_types.h"

/* Function Declarations */
extern void mexFunction(int32_T nlhs, mxArray *plhs[], int32_T nrhs, const
  mxArray *prhs[]);
extern emlrtCTX mexFunctionCreateRootTLS(void);

#endif

/* End of code generation (_coder_modulation_pmf_update_Linux_mex.h) */
