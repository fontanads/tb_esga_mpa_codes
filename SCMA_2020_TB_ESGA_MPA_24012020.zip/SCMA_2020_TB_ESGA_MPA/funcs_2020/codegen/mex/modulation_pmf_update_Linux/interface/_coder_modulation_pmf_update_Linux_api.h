/*
 * _coder_modulation_pmf_update_Linux_api.h
 *
 * Code generation for function '_coder_modulation_pmf_update_Linux_api'
 *
 */

#ifndef _CODER_MODULATION_PMF_UPDATE_LINUX_API_H
#define _CODER_MODULATION_PMF_UPDATE_LINUX_API_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "modulation_pmf_update_Linux_types.h"

/* Function Declarations */
extern void modulation_pmf_update_Linux_api(const mxArray * const prhs[2],
  int32_T nlhs, const mxArray *plhs[1]);

#endif

/* End of code generation (_coder_modulation_pmf_update_Linux_api.h) */
