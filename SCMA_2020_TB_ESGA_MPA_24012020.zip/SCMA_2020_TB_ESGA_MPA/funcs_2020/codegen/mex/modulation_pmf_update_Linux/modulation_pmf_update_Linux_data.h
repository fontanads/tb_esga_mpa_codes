/*
 * modulation_pmf_update_Linux_data.h
 *
 * Code generation for function 'modulation_pmf_update_Linux_data'
 *
 */

#ifndef MODULATION_PMF_UPDATE_LINUX_DATA_H
#define MODULATION_PMF_UPDATE_LINUX_DATA_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "modulation_pmf_update_Linux_types.h"

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern const volatile char_T *emlrtBreakCheckR2012bFlagVar;
extern emlrtContext emlrtContextGlobal;
extern emlrtRSInfo l_emlrtRSI;

#endif

/* End of code generation (modulation_pmf_update_Linux_data.h) */
