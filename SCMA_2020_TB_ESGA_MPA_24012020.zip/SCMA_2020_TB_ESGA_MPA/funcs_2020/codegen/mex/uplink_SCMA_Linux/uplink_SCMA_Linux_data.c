/*
 * uplink_SCMA_Linux_data.c
 *
 * Code generation for function 'uplink_SCMA_Linux_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "uplink_SCMA_Linux.h"
#include "uplink_SCMA_Linux_data.h"

/* Variable Definitions */
emlrtCTX emlrtRootTLSGlobal = NULL;
const volatile char_T *emlrtBreakCheckR2012bFlagVar = NULL;
emlrtContext emlrtContextGlobal = { true,/* bFirstTime */
  false,                               /* bInitialized */
  131466U,                             /* fVersionInfo */
  NULL,                                /* fErrorFunction */
  "uplink_SCMA_Linux",                 /* fFunctionName */
  NULL,                                /* fRTCallStack */
  false,                               /* bDebugMode */
  { 2045744189U, 2170104910U, 2743257031U, 4284093946U },/* fSigWrd */
  NULL                                 /* fSigMem */
};

/* End of code generation (uplink_SCMA_Linux_data.c) */
