/*
 * uplink_SCMA_Linux_terminate.h
 *
 * Code generation for function 'uplink_SCMA_Linux_terminate'
 *
 */

#ifndef UPLINK_SCMA_LINUX_TERMINATE_H
#define UPLINK_SCMA_LINUX_TERMINATE_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "uplink_SCMA_Linux_types.h"

/* Function Declarations */
extern void uplink_SCMA_Linux_atexit(void);
extern void uplink_SCMA_Linux_terminate(void);

#endif

/* End of code generation (uplink_SCMA_Linux_terminate.h) */
