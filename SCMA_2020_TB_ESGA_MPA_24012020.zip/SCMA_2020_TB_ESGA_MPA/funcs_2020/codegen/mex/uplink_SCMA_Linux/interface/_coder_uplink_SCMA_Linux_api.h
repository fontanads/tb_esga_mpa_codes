/*
 * _coder_uplink_SCMA_Linux_api.h
 *
 * Code generation for function '_coder_uplink_SCMA_Linux_api'
 *
 */

#ifndef _CODER_UPLINK_SCMA_LINUX_API_H
#define _CODER_UPLINK_SCMA_LINUX_API_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "uplink_SCMA_Linux_types.h"

/* Function Declarations */
extern void uplink_SCMA_Linux_api(const mxArray * const prhs[9], int32_T nlhs,
  const mxArray *plhs[3]);

#endif

/* End of code generation (_coder_uplink_SCMA_Linux_api.h) */
